# atsiskaitymas
